# Applying this package

Place the two Markdown documents in `research/CTC-003/closure-candidate/` and the JSON check results in `tests/CTC-003/`. This package is **additive**, not a replacement of authoritative root registers. After review and explicit approval, update BACKLOG.md, DECISIONS.md, MODEL-BASELINE.md and SESSION-LOG.md from your current Git checkout. No GitHub write occurred.
