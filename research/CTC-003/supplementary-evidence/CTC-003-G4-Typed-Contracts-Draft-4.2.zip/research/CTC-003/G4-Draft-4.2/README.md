Additive research package only. Copy to research/CTC-003/G4-Draft-4.2/. No authoritative register replacements or accepted schema changes.
