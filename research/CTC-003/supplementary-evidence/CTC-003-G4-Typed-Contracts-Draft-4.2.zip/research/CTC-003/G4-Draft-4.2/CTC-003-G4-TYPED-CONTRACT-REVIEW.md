# CTC-003 G4 — Typed Field Contracts, Draft 4.2

**Status: Proposed.** Based on Draft 4.1 (43 adjudication rows), the 299-path candidate registry and 45 high-risk destination components. Latest GitHub HEAD and authoritative normative schema not independently verified.

## Deliverables

- `FIELD-CONTRACTS.csv`: **18 candidate fields**, each with owner, logical type, conditional cardinality, applicability, provenance and unresolved constraint.
- `VALUE-OBJECTS.csv`: **11 proposed value-object structures**, not independent aggregate roots.
- `TEST-RESULTS.json`: **8/8 focused synthetic checks** (one valid control, seven invalid cases).

## Key proposed rules

1. `FiscalIdentity.value` cannot be approved as a bare string: identity scheme, subject and jurisdiction must be retained. Its exact canonical path is unresolved.
2. `FiscalEvidence.authorityRef` must be typed as fiscal identity, certification-event reference or submission correlation; ambiguous values must remain unresolved.
3. `FiscalEvidence.signatureRef` and `signatureValueRef` are competing candidates, not independently writable authoritative fields. Choose an alias/owner before freeze.
4. A signed representation's metadata is not equivalent to legal certification evidence.
5. `PaymentInstruction` and `PaymentTerms` have distinct meanings. Account values require privacy controls.
6. `MandateScope` must retain effective dates and jurisdiction; an external format version is not a profile-package version.
7. Collection selectors such as `[*]` remain mapping syntax, not canonical field declarations.
8. Globally optional fields can become mandatory under an applicable document type, stage or jurisdiction profile; no new universal country rule is assumed.

## Validation and limitations

The 8/8 checks cover typed fiscal identity, external reference type, mandate scope, artifact digest, signature alias conflict and payment instruction. They do not validate all 299 registry paths, all 45 mappings, or complete Peppol/CFDI round trips. This is a contract proposal, not regulatory conformance.

## Decision status

D2, P1–P7, I-01–I-10, T01–T03, D01–D03, L01–L10, B01–B10, qualified C09 and G2 logical directions remain accepted within prior scope. No new ADR or schema accepted. Physical FiscalContext A/B/C deferred. **CTC-003 remains Review.**

## Checkpoint

Findings: typed value objects can resolve many documentation gaps without adding aggregates. Proposed ADRs: none approved. Suggested update: add this research under `research/CTC-003/G4-Draft-4.2/`. Next: resolve signature aliases and authority-reference types, reconcile against one normative candidate dictionary, then test complete independent UBL/CFDI transformations and field-level loss.
